import React from 'react';

function Language() {
  return (
    <>
      <select className="select" name="" id="">
              <option value="English">English</option>
              <option value="Hindi">Hindi</option>
            </select>
    </>
  );
}

export default Language;
